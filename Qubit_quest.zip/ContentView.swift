import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
        ZStack{
            
            
                let fudgeBeige = Color(hue: 0.1, saturation: 0.3, brightness: 0.8)
    
            LinearGradient(gradient: Gradient(colors: [Color.white,Color.teal]), startPoint: .topLeading, endPoint: /*@START_MENU_TOKEN@*/.bottomTrailing/*@END_MENU_TOKEN@*/).ignoresSafeArea(.all)
                
                VStack {
                    
                    
                        Text("Qubit_quest")
                            .font(.system(size:40,weight: .bold ,design: .default))
                            .frame(width: 300,height: 80)
                            .foregroundColor(.black)
                            .background(Color(white: 1))
                            .padding(.top,50)
                            .cornerRadius(20)
                    
                    
                    Text("Know about qubits through a game ")
                        .multilineTextAlignment(.center)
                        .font(.system(size:30,weight: .semibold,design: .default))
                        .frame(width: 300 , height: 100)
                        .foregroundColor(.black)
                        .padding(.top , 30)
                    Spacer()
                    HStack (spacing : 40){
                        Image( "qubit-image")
                            .resizable()
                            .frame(width: 200,height:250)
                            .padding()
                            .background(fudgeBeige)
                            .cornerRadius(30)
                        
                  
                    }
                    
                    Spacer()
                     
                    Spacer()
                        
                        NavigationLink(destination: rules(), label :
                        {
                            Text("Instructions")
                                .font(.system(size: 40,weight:.regular, design: .default))
                                .frame(width: 300,height: 40)
                                .foregroundColor(.blue)
                                .padding(.all)
                                .background(Color(white: 0.8))
                                .cornerRadius(100)
                            
                            
                        })
                    
                    
                    
                    Spacer()
                        
                        
              
                }
                
            }
        }.navigationBarBackButtonHidden(true)
    }

}
