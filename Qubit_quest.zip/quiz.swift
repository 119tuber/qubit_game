//
//  probability-view.swift
//  qubit
//
//  Created by karanjeet on 20/02/24.
//

import SwiftUI




var  quantum1 :[Int] = Array(repeating: 0, count: 5)
func quantumarray(a: Int) -> [Int] {
    var rarray: [Int] = Array(repeating: 0, count: 5)
    for index in 0..<a {
        rarray[index]=1
        
    }

    return rarray.shuffled()
}
   
    
let questions = ["Choose your business car color", " Choose off-raoding your car color ", "Choose your adventure car color", "Choose your racing car color", "Choose your daily commute car color "]
    

struct quiz : View {
    
    // define  state
    @State var  per : Double
    @State var col1 : Color
    @State var col2 : Color
    
    @State private var cQuestionIndex = 0
    
    @State private var selectedOption : [Int] = Array(repeating: 2, count: 5)

    @State var score : Int = 0
    var body: some View {
        let rcol2 = col1.description
        let rcol1 = col2.description
        let number1 = Int(round((per*5)))
        
           NavigationView {
            
               ZStack {
                   LinearGradient(gradient: Gradient(colors: [Color.white,Color.teal]), startPoint: .topLeading, endPoint: /*@START_MENU_TOKEN@*/.bottomTrailing/*@END_MENU_TOKEN@*/).ignoresSafeArea(.all)
                   
                   
                   VStack (spacing:10){
                     
                       HStack {
                           NavigationLink(destination: carview(color1: col1, color2: col2) , label: {
                               Text("< Back")
                                   .font(.system(size: 20,weight:.light, design: .default))
                                   .frame(width: 100,height: 10)
                                   .foregroundColor(.blue)
                                   .padding(.leading,1)
                               
                                   
                               
                           })
                           Spacer()
                       }
                       

                       Text(" Quiz ")
                           .font(.system(size: 30 , weight: .semibold , design: .default))
                           .frame(width: 100 , height: 30)
                           .multilineTextAlignment(.center)
                           .padding(.all,6)
                           
                          // .background(Color(white: 0.7))
                           .cornerRadius(20)
                         
                       
                       
                       // queston  1
                       Text(questions[0])
                           .font(.title3)
                       Picker("Select an option", selection: $selectedOption[0]) {
                           Text("\(rcol1)").tag(1)
                           Text("\(rcol2)").tag(0)
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .frame(width: 200 , height: 18)
                       .font(.headline)
                       .padding(.all,6)
                       
                       
                       //questioin 2
                       Text(questions[1])
                           .font(.title3)
                       Picker("Select an option", selection: $selectedOption[1]) {
                           Text("\(rcol1)").tag(1)
                           Text("\(rcol2)").tag(0)
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .frame(width: 200 , height: 18)
                       .font(.headline)
                       .padding(.all,5)
                       
                       
                       // question 3
                       Text(questions[2])
                           .font(.title3)
                       Picker("Select an option", selection: $selectedOption[2]) {
                           Text("\(rcol1)").tag(1)
                           Text("\(rcol2)").tag(0)
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .frame(width: 200 , height: 18)
                       .font(.headline)
                       .padding(.all,6)
                       
                       //question 4
                       Text(questions[3])
                           .font(.title3)
                       Picker("Select an option", selection: $selectedOption[3]) {
                           Text("\(rcol1)").tag(1)
                           Text("\(rcol2)").tag(0)
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .frame(width: 200 , height: 18)
                       .font(.headline)
                       .padding(.all,6)
                       
                       
                       //question 5
                       
                       Text(questions[4])
                           .font(.title3)
                       Picker("Select an option", selection: $selectedOption[4]) {
                           Text("\(rcol1)").tag(1).background(Color.red)
                           Text("\(rcol2)").tag(0).background(Color.gray)
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .frame(width: 200 , height: 18)
                       .font(.headline)
                       .padding([.leading,.trailing,.top],6)
                       
                       // buuton for hint
                       
                       Text("Hint : (percentage correspondence to the probability distributions of Colors)")
                           .font(.headline)
                           .multilineTextAlignment(.center)
                           .frame(width: 350 ,height:  60)
                           .padding(.top)
                       
                       
                       // done button
                       HStack  (spacing : 30 ){
                           Button(action: {
                               quantum1 = quantumarray(a:number1 )
                               for i in 0...4 {
                                   if quantum1[i] == selectedOption[i] {
                                       score = score + 1
                                   }
                                   
                               }
                           }, label: {
                               Text("Done")
                                   .font(.system(size: 25))
                                   .foregroundColor(Color.blue)
                                   .frame(width : 80 , height: 50)
                                   .background(Color(white: 0.7))
                                   .cornerRadius(10)
                           })
                           
                           Text("your score is \(score)")
                               .font(.title)
                               .padding()
                       }
                       
                       //play again
                       Button(action:
                                {
                           score = 0
                         selectedOption = Array(repeating: 2, count: 5)
                       }, label : {
                           Text("Play Again ")
                               .font(.system(size: 40,weight:.regular, design: .default))
                               .frame(width: 300,height: 40)
                               .foregroundColor(.blue)
                               .padding(.all)
                               .background(Color(white: 0.8))
                               .cornerRadius(100)
                               
                       })
                       .padding(.top,15)
                       
                       
                   }
               }
            
        }.navigationBarBackButtonHidden(true)
        

        }

        
    }

