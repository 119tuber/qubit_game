
//  nextone.swift
//  qubit
//
//  Created by karanjeet on 18/02/24.
//

import Foundation
import SwiftUI

struct colors : View {

    @State   var  butcolor1 : Color = Color.red
    @State   var  butcolor2 : Color = Color.blue
    @State   var  tapcount = 0
    
    // for hovering
    @State private var isHovered = false
    @State private var isFocused = false
      
    var body : some View {
        
        NavigationView {
        
            ZStack{
                
                LinearGradient(gradient: Gradient(colors: [Color.white,Color.teal]), startPoint: .topLeading, endPoint: /*@START_MENU_TOKEN@*/.bottomTrailing/*@END_MENU_TOKEN@*/).ignoresSafeArea(.all)
                VStack (){
                    HStack{
                        NavigationLink(destination: rules(), label:{
                            
                            Text("< Back")
                                .font(.system(size: 20,weight:.light, design: .default))
                                .frame(width: 100,height: 10)
                                .foregroundColor(.blue)
                                .padding(.vertical,8)
                                .padding(.bottom,15)
                               // .padding(.top,10)
                                .padding(.trailing,5)
                            
                                 
                           
                        } )
                        Spacer()
                    }
                    
                    
                    Text("Choose the colors for quantum car   ")
                        .font(.system(size:30,weight: .semibold,design: .default))
                        .frame(width: 300, height : 80)
                        .multilineTextAlignment(.center)
                        .padding(.all)
                        
                      
                        .cornerRadius(30)
                        .padding(.bottom)
                    
                    HStack (spacing : 15){
                        
                        Button(action: {
                            tapcount = tapcount+1
                            if tapcount%2 == 0  && butcolor2 != Color.purple{
                                butcolor1 = Color.purple
                                tapcount=0
                            }
                            else if tapcount%2==1 && butcolor1 != Color.purple{
                                butcolor2 = Color.purple
                                tapcount=1
                            }
                            else {
                                butcolor2 = Color.black
                            }
                        }, label: {
                            Text("")
                                .font(.system(size: 40, weight: .heavy , design: .default))
                                .frame(width:20,height: 20)
                                .padding()
                                .background(Color(uiColor: .purple))
                                .cornerRadius(30)
                        })
                        
                        Button(action: {
                            tapcount = tapcount + 1
                            if tapcount%2 == 0  && butcolor2 != Color.blue{
                                butcolor1 = Color.blue
                                tapcount=0
                            }
                            else if tapcount%2==1 && butcolor1 != Color.blue{
                                butcolor2 = Color.blue
                                tapcount=1
                            }
                            else {
                                butcolor2 = Color.black
                            }
                        }, label: {
                            Text("")
                                .font(.system(size: 40, weight: .heavy , design: .default))
                                .frame(width:20,height: 20)
                                .padding()
                                .background(Color(uiColor: .blue))
                                .cornerRadius(30)
                        })
                        Button(action: {
                            tapcount = tapcount + 1
                            if tapcount%2 == 0  && butcolor2 != Color.yellow{
                                butcolor1 = Color.yellow
                                tapcount=0
                                
                            }
                            else if (tapcount%2 == 1 && butcolor1 != Color.yellow){
                                butcolor2 = Color.yellow
                                tapcount=1
                            }
                            else {
                                butcolor2 = Color.black
                            }
                        }, label: {
                            Text("")
                                .font(.system(size: 40, weight: .heavy , design: .default))
                                .frame(width:20,height: 20)
                                .padding()
                                .background(Color(uiColor: .yellow))
                                .cornerRadius(30)
                        })
                        Button(action: {
                            tapcount = tapcount + 1
                            if tapcount%2 == 0  && butcolor2 != Color.green{
                                butcolor1 = Color.green
                                tapcount=0
                            }
                            else if tapcount%2==1 && butcolor1 != Color.green{
                                butcolor2 = Color.green
                                tapcount=1
                            }
                            else {
                                butcolor2 = Color.black
                            }
                        }, label: {
                            Text("")
                                .font(.system(size: 40, weight: .heavy , design: .default))
                                .frame(width:20,height: 20)
                                .padding()
                                .background(Color(uiColor: .systemMint))
                                .cornerRadius(30)
                        })
                        Button(action: {
                            tapcount = tapcount + 1
                            if tapcount%2 == 0  && butcolor2 != Color.red{
                                butcolor1 = Color.red
                                tapcount=0
                            }
                            else if tapcount%2==1 && butcolor1 != Color.red{
                                butcolor2 = Color.red
                                tapcount=1
                            }
                            else {
                                butcolor2 = Color.black
                            }
                        }, label: {
                            Text("")
                                .font(.system(size: 40, weight: .heavy , design: .default))
                                .frame(width:20,height: 20)
                                .padding()
                                .background(Color(uiColor: .red))
                                .cornerRadius(30)
                        })
                        
                        
                        
                    }
                    
                    VStack () {
                        HStack (spacing : 20) {
                    
                            
                            Image(systemName: "car.fill")
                                .resizable()
                                .frame(width:120,height: 120)
                                .padding()
                                .foregroundColor(butcolor2)
                                .background(Color.init(white: 0.9 ))
                                .cornerRadius(20)
                                .scenePadding(.trailing)
                            Text("color 1")
                                .font(.system(size: 30,weight: .regular ,design: .default))
                                .multilineTextAlignment(.center)
                                .frame(width:100,height: 100)
                                .padding(.horizontal)
                                .background(Color.init(white: 0.9 ))
                                .cornerRadius(20)
                                .scenePadding(.trailing)
                            
                            
                        }
                        .scenePadding()
                        HStack (spacing : 20) {
                            Text("color 2")
                                .font(.system(size: 30,weight: .regular ,design: .default))
                                .multilineTextAlignment(.center)
                                .frame(width:100,height: 100)
                                .padding(.horizontal)
                                .background(Color.init(white: 0.9 ))
                                .cornerRadius(20)
                                .scenePadding(.leading)
                            
                            Image(systemName: "car.fill")
                                .resizable()
                                .frame(width:120,height: 120)
                                .padding()
                                .foregroundColor(butcolor1)
                                .background(Color.init(white: 0.9 ))
                                .cornerRadius(20)
                                .scenePadding(.leading)
                            
                           
                        }.scenePadding()
                    }
                    
                    NavigationLink(destination: carview(color1 : butcolor1,color2 : butcolor2), label:{
                        Text("Quantum car")
                            .font(.system(size: 40,weight:.regular, design: .default))
                            .frame(width: 300,height: 40)
                            .foregroundColor(.blue)
                            .padding(.all)
                            .background(Color(white: 0.8))
                            .cornerRadius(100)
                            .padding(.top,20)
                        
                    } )
                    
                }
            }
        }.navigationBarBackButtonHidden(true)
        }
    }
    

