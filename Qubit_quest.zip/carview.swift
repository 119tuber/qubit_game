
//
//  carview.swift
//  qe
//
//  Created by karanjeet on 20/02/24.
//

import SwiftUI


extension Color {
    static func mixColors(color1: Color, color2: Color, percentage: Double) -> Color {
        let clampedPercentage = max(0, min(1, percentage))

        let components1 = color1.components()
        let components2 = color2.components()

        let blendedComponents = zip(components1, components2).map { component1, component2 in
            (1 - clampedPercentage) * component1 + clampedPercentage * component2
        }

        return Color(red: blendedComponents[0], green: blendedComponents[1], blue: blendedComponents[2])
    }

    func components() -> [Double] {
        let uiColor = UIColor(self)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: nil)
        return [Double(red), Double(green), Double(blue)]
    }
}

struct carview : View {
    @State  var color1 : Color
    @State  var color2 : Color
    @State  var percent : Double = 0.5

    @State var value : Double = 0.5
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.white,Color.teal]), startPoint: .topLeading, endPoint: /*@START_MENU_TOKEN@*/.bottomTrailing/*@END_MENU_TOKEN@*/).ignoresSafeArea(.all)
                
                VStack  (spacing : 20){
                    HStack {
                        NavigationLink(destination: colors(), label:{
                            Text("< Back")
                                .font(.system(size: 20,weight:.light, design: .default))
                                .frame(width: 100,height: 10)
                                .foregroundColor(.blue)
                                .padding(.vertical)
                                .padding(.bottom,40)
                                
                            
                        } )
                        Spacer()
                    }
               
                    
                    VStack {
                        Text(" Your Quantum car is here ! ")
                            .font(.system(size: 30 ,weight: .semibold ,design: .default))
                            .frame(width: 250 , height: 100)
                            .multilineTextAlignment(.center)
                            
                     
                            .cornerRadius(30)
                            .scenePadding()
                        
                        
                        
                        
                        Image(systemName: "car.fill")
                            .resizable()
                            .frame(width:120,height: 120)
                            .padding()
                            .foregroundColor(Color.mixColors(color1: color1, color2: color2, percentage: percent))
                            .background(Color.init(white: 0.9 ))
                            .cornerRadius(20)
                            .padding(.bottom ,30)
                        
                      }.padding(.bottom,30)
                    
           
                      
                    HStack () {  Text("")
                            .font(.system(size: 20 , weight: .bold ,design: .default))
                            .frame(width: 30 , height: 20)
                            .padding()
                            .background(color1)
                            .cornerRadius(10)
                            .scenePadding(.horizontal)
                        
                        Slider(value: $percent, in: 0...1)
                        
                        Text("")
                            .font(.system(size: 20 , weight: .bold ,design: .default))
                            .frame(width: 30 , height: 20)
                            .padding()
                            .background(color2)
                            .cornerRadius(10)
                            .scenePadding(.horizontal)
                        
                    }
                    
                    HStack (spacing : 55) {
                        
                        Text("  \(Int(percent*100))% ")
                            .font(.system(size: 20 ,weight: .regular  , design: .serif))
                            .frame(width: 70 , height: 50 )
                            .multilineTextAlignment(.center)
                            .padding(.horizontal,2)
                            .background(Color(white: 0.9))
                            .cornerRadius(10)
                       
                        
                        
                        Text(" The slider")
                            .font(.system(size: 20 , weight: .semibold , design: .default))
                        
                        Text(" \(Int((1-percent)*100)) % ")
                            .font(.system(size: 20 ,weight: .regular  , design: .serif))
                            .frame(width: 70, height: 50 )
                            .multilineTextAlignment(.center)
                            .padding(.horizontal,2)
                            .background(Color(white: 0.9))
                            .cornerRadius(10)
                      
                    }
          
                    HStack {
                        
                        // link to probability page
                        NavigationLink(destination: quiz(per: percent,col1: color2,col2: color1 ), label: {
                            Text("Try  quiz")
                                .font(.system(size: 40,weight:.regular, design: .default))
                                .frame(width: 300,height: 40)
                                .foregroundColor(.blue)
                                .padding(.all)
                                .background(Color(white: 0.8))
                                .cornerRadius(100)
                                
                            
                        })
                        
                    }.padding(.top , 40)
        
                }
                    
                
            }
        }.navigationBarBackButtonHidden(true)
    }
    
    
}


