//
//  observation.swift
//  qe
//
//  Created by karanjeet on 22/02/24.
//

import SwiftUI

struct rules: View {
    var body: some View {
        NavigationView {
            
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color.white,Color.teal]), startPoint: .topLeading, endPoint: /*@START_MENU_TOKEN@*/.bottomTrailing/*@END_MENU_TOKEN@*/).ignoresSafeArea(.all)
                VStack
                { HStack {
                    NavigationLink(destination: ContentView(), label:{
                        
                        Text("< Back")
                            .font(.system(size: 20,weight:.light, design: .default))
                            .frame(width: 100,height: 10)
                            .foregroundColor(.blue)
                            .padding(.vertical)
                            
                            
                        
                        
                        
                        
                        Spacer()
                    } )
                }
                   
                    VStack {
                        Text(" Instructions ")
                            .font(.system(size:30,weight: .semibold,design: .default))
                            .frame(width:300 ,height: 30)
                            .padding(.horizontal)
                        
                        VStack(alignment : .leading) {
                            
                            Text("1. Choose two color options for the quantum car.")
                                .font(.system(size: 23,weight: .regular , design: .default ))
                            
                                .multilineTextAlignment(.leading)
                                .padding()
                            
                            
                            Text("2. For varying proportion of colors move the slider accordingly.")
                                .font(.system(size: 23,weight: .regular, design: .default ))
                           
                                .multilineTextAlignment(.leading)
                                .padding()
                            
                            Text("3.⁠ After quantum car generated (e.g.,75% of color1 and 25% of color2). Proceed to play a quiz.")
                                .font(.system(size: 23,weight: .regular , design: .default ))
                       
                                .multilineTextAlignment(.leading)
                                .padding()
                            Text("4.⁠ All quiz cars will mimic your generated quantum car color scheme (75% color1, 25% color2).")
                                .font(.system(size: 23,weight: .regular, design: .default ))
                     
                                .multilineTextAlignment(.leading)
                                .padding()
                            
                            Text("⁠5. On 'Done', get score reflecting the alignment of your choices with quantumly-predicted choices.")
                                .font(.system(size: 23,weight: .regular, design: .default ))
                                .multilineTextAlignment(.leading)
                                .padding()
                        }
                        NavigationLink(destination: colors(), label :
                                        {
                            Text("Play")
                                .font(.system(size: 40,weight:.regular, design: .default))
                                .frame(width: 300,height: 40)
                                .foregroundColor(.blue)
                                .padding(.all)
                                .background(Color(white: 0.8))
                                .cornerRadius(100)
                         
                            
                        })
                        
                        
                    }
                }
                
            }
        }.navigationBarBackButtonHidden(true)
    }
}


